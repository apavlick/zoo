package com.example.zoo.controllers;

import com.example.zoo.exhibit.Jungle;
import com.example.zoo.exhibit.Savannah;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ZooController {

    @Autowired
    Jungle jungle;

    @Autowired
    Savannah savannah;

    @GetMapping(value= "/jungle")
    public String jungleExhibit(){
        return jungle.display();
    }

    @GetMapping(value= "/savannah")
    public String savannahExhibit(){
        return savannah.display();
    }
}
