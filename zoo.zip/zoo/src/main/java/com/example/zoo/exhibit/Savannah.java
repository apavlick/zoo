package com.example.zoo.exhibit;


import com.example.zoo.animal.Cat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Savannah implements Exhibit{


    private Cat cat;

    @Autowired
    public Savannah(@Qualifier("lion") Cat c){
        this.cat = c;
    }

    @Override
    public String display() {
        return "Animal Type: " + " Animal name: " + cat.getName() + " Animal age: " + cat.getAge()
                + "-------" + cat.roar() + " and " + cat.run();
    }
}
