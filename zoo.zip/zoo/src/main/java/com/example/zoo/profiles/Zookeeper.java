package com.example.zoo.profiles;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("zookeeper")
public class Zookeeper implements Employee {
    @Override
    public String doWork() {
        return "ZooKeeper is working today and feeding the animals...";
    }
}
