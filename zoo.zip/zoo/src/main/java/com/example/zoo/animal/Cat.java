package com.example.zoo.animal;

abstract public class Cat implements Animal {
    private String name;
    private String age;
    public abstract String roar();
    public abstract String run();
    public abstract String getName();
    public abstract String getAge();

}
