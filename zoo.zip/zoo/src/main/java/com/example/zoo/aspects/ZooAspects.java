package com.example.zoo.aspects;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;
import com.example.zoo.exhibit.*;


/*
-This whole class is an "aspect"
-The individual methods are "advice"
-Where/when each method gets called are "pointcuts"
 */
@Aspect
@Component
//@EnableAspectJAutoProxy, why don't I need this but in the youtube video I did? -> https://www.youtube.com/watch?v=Ft29HgsePfQ
public class ZooAspects {

    @Before("execution(* com.example.zoo.exhibit.Exhibit.display(..))")
    public void openTheZoo(){
        System.out.println("Good Morning! The zoo is open for business!");
    }

    @After("execution(* com.example.zoo.exhibit.Exhibit.display(..))")
    public void closeTheZoo(){
        System.out.println("The zoo is closing! Drive home safely...");
    }
}
