package com.example.zoo.exhibit;

public interface Exhibit {
    public String display();
}
