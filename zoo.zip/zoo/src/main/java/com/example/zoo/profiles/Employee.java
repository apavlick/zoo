package com.example.zoo.profiles;

public interface Employee {
    public String doWork();
}
