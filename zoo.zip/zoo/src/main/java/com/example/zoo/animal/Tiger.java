package com.example.zoo.animal;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:application.properties")
public class Tiger extends Cat{

    private String name;
    private String age;

    public Tiger(@Value("${tiger.name}") String name, @Value("${tiger.age}") String age){
        this.name = name;
        this.age = age;
    }

    @Override
    public String roar() {
        return "The Tiger Roars!!!";
    }

    @Override
    public String run() {
        return "The Tiger chases its prey!!!";
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getAge() {
        return age;
    }
}
