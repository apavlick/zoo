package com.example.zoo.animal;

public interface Animal {
}
