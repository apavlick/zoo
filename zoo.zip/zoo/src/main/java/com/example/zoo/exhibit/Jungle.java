package com.example.zoo.exhibit;

import com.example.zoo.animal.Cat;
import com.example.zoo.profiles.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Jungle implements Exhibit {

    private Cat cat;
    private Employee employee;


    @Autowired
    public Jungle(@Qualifier("tiger") Cat c, Employee e){
        this.cat = c;
        this.employee = e;
    }


    @Override
    public String display() {
        return "Animal Type: " + " Animal name: " + cat.getName() + ",   " + " Animal age: " + cat.getAge()
                + "-------" + cat.roar() + " and " + cat.run() + " and " + employee.doWork();
    }
}
