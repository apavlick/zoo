package com.example.zoo.animal;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:application.properties")
public class Lion extends Cat {

    private String name;
    private String age;

    public Lion(@Value("${lion.name}") String name, @Value("${lion.age}")String age){
        this.name = name;
        this.age = age;
    }
    @Override
    public String roar() {
        return "The Lion Roars!!!";
    }

    @Override
    public String run() {
        return "The Lion chases its Prey!!!";
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getAge() {
        return age;
    }
}
