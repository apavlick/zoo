package com.example.zoo.profiles;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("scientist")
public class Scientist implements Employee{

    @Override
    public String doWork() {
        return "Scientist is working today and is studying the animals...";
    }
}
